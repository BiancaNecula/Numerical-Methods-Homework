function [percentage] = evaluate(path_to_testset, w, histogram, count_bins)
endfunction