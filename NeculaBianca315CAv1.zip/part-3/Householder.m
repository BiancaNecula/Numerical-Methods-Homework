function [Q, R] = Householder(A, b)
	[m n] = size(A);	Q = eye(m);
	
	for p = 1 : min(m-1,n)
		sigma = -norm(A(p:m, p));
		if A(p, p) < 0
			sigma = -sigma;
		end;

		% calculare reflector Householder
		vp(1:m, 1) = 0;
		vp(p) = A(p, p) + sigma;
		vp(p + 1:m) = A(p + 1:m, p);
    
		beta = sigma * vp(p);
	
		if beta ~= 0
      % transformare coloana p din Ap
      A(p, p) = -sigma;
		  A(p + 1:m, p) = 0;
		  
      %transformare coloanele p+1:n din Ap
      for j = p + 1 : n
		    t = vp(p:m)' * A(p:m, j) / beta;
		    A(p:m, j) = A(p:m, j) - t * vp(p:m);
		  end;

 	  % bp+1 = Hp * bp
      t = vp(p:m)' * b(p:m) / beta;
		  b(p:m) = b(p:m) - t * vp(p:m);
	
  	  %transformare coloanele 1:n din H
		  for j = 1:m
		    t = vp(p:m)' * Q(p:m, j) / beta;
		    Q(p:m, j) = Q(p:m, j) - t * vp(p:m);
		  end;
     end
  end;
  
	R = -A;
	Q = Q';
  
%[m,n] = size(A);
%W = zeros(m,n);
%R = A;
%for k = 1:n
% x = R(k:m,k);
% v = x;
% v(1) = sign(x(1))*norm(x) + v(1);
% v = v/norm(v);
% R(k:m,k:n) = R(k:m,k:n) - 2*v*(v'*R(k:m,k:n));
% W(k:m,k) = v; 
%endfor
%[m, n] = size(W);
%Q = eye(m);
%for k = n:-1:1
%  v = W(k:m,k);
%  Q(k:m,:) = Q(k:m,:) - 2*v*(v'*Q(k:m,:));
%endfor 
%n = size(A,1);
%Q=eye(n); 
%R=A; 
%I = eye(n);
%for j=1:n-1
%  x=R(j:n,j);
%  v=-sign(x(1))*norm(x)*eye(n-j+1,1)-x;
%  if norm(v)>0
%    v=v/norm(v);
%    P=I; 
%    P(j:n,j:n)=P(j:n,j:n)-2*v*v';
%    R=P*R;
%    Q=Q*P;
%  endif
%endfor
endfunction