function [w] = learn(X, y)
  X_tilda = [X ones(size(X,1),1)];
  [Q, R] = Householder(X_tilda, y);
  [Q2, R2] = qr(X_tilda);
  %Q==Q2
  [w] = SST(R, Q' * y);
 %w = R\(Q'*y)
 %w = X_tilda\y
end
